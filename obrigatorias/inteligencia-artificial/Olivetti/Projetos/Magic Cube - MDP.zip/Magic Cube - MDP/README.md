# MagicCube2x2-MDP

Trabalho realizado para inteligência artificial 

Projeto: Resolução de um cubo mágico 2x2 utilizando MDP

Autor: Gilmar Correia Jeronimo - 11014515
